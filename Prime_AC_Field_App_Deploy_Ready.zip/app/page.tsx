"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import { Camera, ClipboardCheck, DollarSign, FileText, Fan, PhoneCall, QrCode, ShieldCheck, Thermometer, Wrench, Zap } from "lucide-react";

const componentList = [
  "Filter",
  "Evaporator Coil",
  "Condenser Coil",
  "Blower Assembly",
  "Blower Motor",
  "Blower Wheel",
  "Fan Motor",
  "Condensate Pump",
  "UV Light",
  "Compressor",
  "Capacitor",
  "Contactor",
  "Transformer",
  "Breaker",
  "Fuses",
  "Circuit Board",
  "Relay",
  "Safety Float Switch",
  "Disconnect Box",
  "Electrical Wiring",
  "Ductwork",
  "Overall System"
];

const initialComponents = Object.fromEntries(
  componentList.map((name) => [
    name,
    { condition: "Good", reading: "", rated: "", notes: "" }
  ])
);

const initialRepairs = [
  { item: "Replace filter", price: 45 },
  { item: "Clean condenser coil", price: 125 },
  { item: "Replace capacitor", price: 210 }
];

function cardClass(extra = "") {
  return "rounded-[28px] border border-slate-200 bg-white shadow-sm " + extra;
}

function inputClass(extra = "") {
  return "w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 outline-none focus:border-sky-500 " + extra;
}

function buttonClass(extra = "") {
  return "rounded-2xl px-4 py-3 font-semibold transition " + extra;
}

function badgeClass(condition: string) {
  if (condition === "Good") return "border-emerald-200 bg-emerald-100 text-emerald-700";
  if (condition === "OK") return "border-amber-200 bg-amber-100 text-amber-700";
  return "border-rose-200 bg-rose-100 text-rose-700";
}

export default function Page() {
  const [activeTab, setActiveTab] = useState("intake");
  const [job, setJob] = useState({
    customerName: "",
    phone: "",
    email: "",
    address: "",
    technician: "",
    workOrder: "PA-10027",
    serviceDate: "",
    unitLocation: "Closet",
    unitType: "Split System",
    tonnage: "3",
    make: "Carrier",
    model: "24ABC636A003",
    serial: "",
    thermostatType: "Smart WiFi",
    refrigerantType: "R-410A",
    refrigerantLevel: "Good",
    returnAir: "75",
    supplyAir: "57",
    tempSplit: "18",
    subcooling: "11",
    superheat: "9",
    staticPressure: "0.52",
    fanMotorAmps: "1.2",
    fanMotorRated: "1.5",
    compressorAmps: "9.6",
    compressorRated: "11.8",
    capacitorValue: "42.8/5",
    capacitorStatus: "Good",
    uvBulb: "Good",
    airflowNotes: "Balanced airflow at all main supply registers.",
    systemResult: "System Operating Properly",
    notes: "Performed full tune-up, flushed drain line, checked electrical, verified refrigerant and temperature split."
  });

  const [components, setComponents] = useState<any>(initialComponents);
  const [repairs, setRepairs] = useState(initialRepairs);
  const [maintenanceActions, setMaintenanceActions] = useState({
    filter: true,
    evap: true,
    cond: true,
    drain: true,
    electrical: true,
    tested: true
  });

  const totals = useMemo(() => {
    const values = Object.values(components) as any[];
    const good = values.filter((c) => c.condition === "Good").length;
    const ok = values.filter((c) => c.condition === "OK").length;
    const defective = values.filter((c) => c.condition === "Defective").length;
    const estimate = repairs.reduce((sum, row) => sum + (Number(row.price) || 0), 0);
    const health = Math.max(0, Math.min(100, Math.round(((good + ok * 0.6) / componentList.length) * 100 - defective * 2)));
    return { good, ok, defective, estimate, health };
  }, [components, repairs]);

  const tabs = [
    ["intake", "Start Job"],
    ["equipment", "Equipment"],
    ["inspection", "Inspection"],
    ["readings", "Readings"],
    ["estimate", "Estimate"],
    ["closeout", "Closeout"]
  ];

  const updateJob = (key: string, value: string) => setJob((prev) => ({ ...prev, [key]: value }));
  const updateComponent = (name: string, key: string, value: string) =>
    setComponents((prev: any) => ({ ...prev, [name]: { ...prev[name], [key]: value } }));

  const SectionButton = ({ value, label }: { value: string; label: string }) => (
    <button
      onClick={() => setActiveTab(value)}
      className={
        "rounded-xl px-3 py-2 text-sm font-semibold " +
        (activeTab === value ? "bg-white text-sky-700 shadow" : "bg-transparent text-slate-600")
      }
    >
      {label}
    </button>
  );

  return (
    <main className="min-h-screen bg-slate-100 p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-2xl">
          <div className="bg-gradient-to-r from-sky-800 via-sky-700 to-cyan-500 px-6 py-8 text-white md:px-8">
            <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr] lg:items-center">
              <div>
                <div className="flex items-center gap-4">
                  <Image src="/prime-logo.png" alt="Prime Air Conditioning" width={84} height={84} className="rounded-2xl bg-white p-2" />
                  <div>
                    <p className="text-xs uppercase tracking-[0.35em] text-sky-100">Prime Air Conditioning</p>
                    <h1 className="mt-2 text-3xl font-bold md:text-5xl">Field App</h1>
                  </div>
                </div>
                <p className="mt-4 max-w-2xl text-sm text-sky-50 md:text-base">
                  Technician workflow for intake, inspection, readings, repair estimates, sign-off, and QR review capture.
                </p>
                <div className="mt-5 flex flex-wrap gap-2 text-xs">
                  {["Mobile Friendly", "Estimate Builder", "Review QR Ready", "Close on Site"].map((item) => (
                    <span key={item} className="rounded-full bg-white/15 px-3 py-2 font-semibold text-white">
                      {item}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-[24px] border border-white/20 bg-white/10 p-5 backdrop-blur">
                  <div className="text-sm text-sky-100">System Health</div>
                  <div className="mt-2 text-3xl font-bold">{totals.health}%</div>
                  <div className="mt-4 h-3 rounded-full bg-white/20">
                    <div className="h-3 rounded-full bg-white" style={{ width: `${totals.health}%` }} />
                  </div>
                </div>
                <div className="rounded-[24px] border border-white/20 bg-white/10 p-5 backdrop-blur">
                  <div className="text-sm text-sky-100">Estimate</div>
                  <div className="mt-2 text-3xl font-bold">${totals.estimate}</div>
                  <div className="mt-4 text-xs text-sky-100">{totals.defective} defective items flagged</div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-6 p-4 md:grid-cols-[280px_1fr] md:p-6">
            <aside className={cardClass()}>
              <div className="p-6">
                <h2 className="text-lg font-bold">Job Snapshot</h2>
                <div className="mt-4 rounded-2xl bg-slate-50 p-4">
                  <div className="font-semibold">{job.customerName || "Customer name"}</div>
                  <div className="mt-1 text-sm text-slate-500">{job.address || "Service address"}</div>
                  <div className="mt-1 text-sm text-slate-500">WO #{job.workOrder}</div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-2xl border p-3 text-center">
                    <div className="text-xs text-slate-500">Good</div>
                    <div className="text-2xl font-bold text-emerald-600">{totals.good}</div>
                  </div>
                  <div className="rounded-2xl border p-3 text-center">
                    <div className="text-xs text-slate-500">OK</div>
                    <div className="text-2xl font-bold text-amber-600">{totals.ok}</div>
                  </div>
                  <div className="rounded-2xl border p-3 text-center">
                    <div className="text-xs text-slate-500">Defective</div>
                    <div className="text-2xl font-bold text-rose-600">{totals.defective}</div>
                  </div>
                  <div className="rounded-2xl border p-3 text-center">
                    <div className="text-xs text-slate-500">Result</div>
                    <div className="text-sm font-bold text-sky-700">{job.systemResult}</div>
                  </div>
                </div>

                <div className="mt-6 space-y-3 text-sm text-slate-600">
                  <div className="flex items-center gap-2"><ClipboardCheck className="h-4 w-4" /> Multi-step workflow</div>
                  <div className="flex items-center gap-2"><DollarSign className="h-4 w-4" /> Estimate ready</div>
                  <div className="flex items-center gap-2"><QrCode className="h-4 w-4" /> Review capture</div>
                  <div className="flex items-center gap-2"><FileText className="h-4 w-4" /> Report + invoice flow</div>
                </div>
              </div>
            </aside>

            <section className={cardClass()}>
              <div className="p-4 md:p-6">
                <div className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-2 lg:grid-cols-6">
                  {tabs.map(([value, label]) => (
                    <SectionButton key={value} value={value} label={label} />
                  ))}
                </div>

                {activeTab === "intake" && (
                  <div className="mt-6 grid gap-4 md:grid-cols-2">
                    <div className={cardClass()}>
                      <div className="p-6">
                        <h3 className="flex items-center gap-2 text-xl font-bold"><PhoneCall className="h-5 w-5" /> Customer Intake</h3>
                        <div className="mt-4 grid gap-4">
                          <div><label className="mb-2 block text-sm font-medium">Customer Name</label><input className={inputClass()} value={job.customerName} onChange={(e) => updateJob("customerName", e.target.value)} placeholder="Enter customer name" /></div>
                          <div className="grid grid-cols-2 gap-4">
                            <div><label className="mb-2 block text-sm font-medium">Phone</label><input className={inputClass()} value={job.phone} onChange={(e) => updateJob("phone", e.target.value)} placeholder="(555) 555-5555" /></div>
                            <div><label className="mb-2 block text-sm font-medium">Email</label><input className={inputClass()} value={job.email} onChange={(e) => updateJob("email", e.target.value)} placeholder="customer@email.com" /></div>
                          </div>
                          <div><label className="mb-2 block text-sm font-medium">Address</label><input className={inputClass()} value={job.address} onChange={(e) => updateJob("address", e.target.value)} placeholder="Service address" /></div>
                          <div className="grid grid-cols-2 gap-4">
                            <div><label className="mb-2 block text-sm font-medium">Technician</label><input className={inputClass()} value={job.technician} onChange={(e) => updateJob("technician", e.target.value)} placeholder="Tech name" /></div>
                            <div><label className="mb-2 block text-sm font-medium">Work Order</label><input className={inputClass()} value={job.workOrder} onChange={(e) => updateJob("workOrder", e.target.value)} /></div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className={cardClass()}>
                      <div className="p-6">
                        <h3 className="flex items-center gap-2 text-xl font-bold"><Camera className="h-5 w-5" /> On-Site Capture</h3>
                        <div className="mt-4 rounded-3xl border-2 border-dashed border-slate-200 bg-slate-50 p-8 text-center">
                          <Camera className="mx-auto h-10 w-10 text-slate-400" />
                          <p className="mt-3 text-sm text-slate-600">Upload equipment photo, data plate, and problem-area pictures.</p>
                          <button className={buttonClass("mt-4 bg-sky-600 text-white")}>Add Photos</button>
                        </div>
                        <div className="mt-4 grid grid-cols-2 gap-4">
                          <div><label className="mb-2 block text-sm font-medium">Service Date</label><input type="date" className={inputClass()} value={job.serviceDate} onChange={(e) => updateJob("serviceDate", e.target.value)} /></div>
                          <div><label className="mb-2 block text-sm font-medium">Unit Location</label><input className={inputClass()} value={job.unitLocation} onChange={(e) => updateJob("unitLocation", e.target.value)} /></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "equipment" && (
                  <div className="mt-6 space-y-4">
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                      <div><label className="mb-2 block text-sm font-medium">Unit Type</label><select className={inputClass()} value={job.unitType} onChange={(e) => updateJob("unitType", e.target.value)}><option>Split System</option><option>Package System</option><option>Water Source</option><option>Through-the-Wall</option></select></div>
                      <div><label className="mb-2 block text-sm font-medium">Tonnage</label><input className={inputClass()} value={job.tonnage} onChange={(e) => updateJob("tonnage", e.target.value)} /></div>
                      <div><label className="mb-2 block text-sm font-medium">Make</label><input className={inputClass()} value={job.make} onChange={(e) => updateJob("make", e.target.value)} /></div>
                      <div><label className="mb-2 block text-sm font-medium">Model</label><input className={inputClass()} value={job.model} onChange={(e) => updateJob("model", e.target.value)} /></div>
                    </div>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                      <div><label className="mb-2 block text-sm font-medium">Serial</label><input className={inputClass()} value={job.serial} onChange={(e) => updateJob("serial", e.target.value)} /></div>
                      <div><label className="mb-2 block text-sm font-medium">Thermostat Type</label><select className={inputClass()} value={job.thermostatType} onChange={(e) => updateJob("thermostatType", e.target.value)}><option>Smart WiFi</option><option>Digital</option><option>Analogue</option></select></div>
                      <div><label className="mb-2 block text-sm font-medium">Refrigerant Type</label><input className={inputClass()} value={job.refrigerantType} onChange={(e) => updateJob("refrigerantType", e.target.value)} /></div>
                      <div><label className="mb-2 block text-sm font-medium">Refrigerant Level</label><select className={inputClass()} value={job.refrigerantLevel} onChange={(e) => updateJob("refrigerantLevel", e.target.value)}><option>Good</option><option>Low</option><option>Overcharged</option></select></div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-3">
                      {[
                        ["Equipment profile", "Store make, model, serial, refrigerant, and thermostat type for repeat visits.", Thermometer],
                        ["Office ready", "Perfect for converting into customer history and maintenance agreements.", ShieldCheck],
                        ["PDF export", "This screen can feed the service report and invoice output automatically.", FileText]
                      ].map(([title, desc, Icon]: any) => (
                        <div key={title} className="rounded-[28px] bg-slate-50 p-6">
                          <Icon className="h-6 w-6 text-sky-600" />
                          <div className="mt-3 font-semibold">{title}</div>
                          <div className="mt-2 text-sm text-slate-600">{desc}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === "inspection" && (
                  <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {componentList.map((name) => (
                      <div key={name} className={cardClass()}>
                        <div className="space-y-4 p-5">
                          <div className="flex items-center justify-between gap-3">
                            <div className="font-semibold">{name}</div>
                            <span className={`rounded-full border px-3 py-1 text-xs font-semibold ${badgeClass(components[name].condition)}`}>{components[name].condition}</span>
                          </div>
                          <div>
                            <label className="mb-2 block text-sm font-medium">Condition</label>
                            <select className={inputClass()} value={components[name].condition} onChange={(e) => updateComponent(name, "condition", e.target.value)}>
                              <option>Good</option>
                              <option>OK</option>
                              <option>Defective</option>
                            </select>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div><label className="mb-2 block text-sm font-medium">Reading</label><input className={inputClass()} value={components[name].reading} onChange={(e) => updateComponent(name, "reading", e.target.value)} placeholder="Value" /></div>
                            <div><label className="mb-2 block text-sm font-medium">Rated / Type</label><input className={inputClass()} value={components[name].rated} onChange={(e) => updateComponent(name, "rated", e.target.value)} placeholder="Spec" /></div>
                          </div>
                          <div><label className="mb-2 block text-sm font-medium">Notes</label><textarea className={inputClass("min-h-[88px]")} value={components[name].notes} onChange={(e) => updateComponent(name, "notes", e.target.value)} placeholder="Inspection notes" /></div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === "readings" && (
                  <div className="mt-6 space-y-4">
                    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                      {[
                        ["Return Air", "returnAir", Thermometer],
                        ["Supply Air", "supplyAir", Thermometer],
                        ["Temp Split", "tempSplit", Thermometer],
                        ["Static Pressure", "staticPressure", Zap],
                        ["Subcooling", "subcooling", Fan],
                        ["Superheat", "superheat", Fan],
                        ["Fan Motor Amps", "fanMotorAmps", Zap],
                        ["Compressor Amps", "compressorAmps", Zap]
                      ].map(([label, key, Icon]: any) => (
                        <div key={key} className={cardClass()}>
                          <div className="p-5">
                            <div className="flex items-center gap-3 text-slate-600"><Icon className="h-5 w-5 text-sky-600" /> {label}</div>
                            <input className={inputClass("mt-4 text-lg font-semibold")} value={(job as any)[key]} onChange={(e) => updateJob(key, e.target.value)} />
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                      <div><label className="mb-2 block text-sm font-medium">Fan Motor Rated</label><input className={inputClass()} value={job.fanMotorRated} onChange={(e) => updateJob("fanMotorRated", e.target.value)} /></div>
                      <div><label className="mb-2 block text-sm font-medium">Compressor Rated</label><input className={inputClass()} value={job.compressorRated} onChange={(e) => updateJob("compressorRated", e.target.value)} /></div>
                      <div><label className="mb-2 block text-sm font-medium">Capacitor µF</label><input className={inputClass()} value={job.capacitorValue} onChange={(e) => updateJob("capacitorValue", e.target.value)} /></div>
                      <div><label className="mb-2 block text-sm font-medium">Capacitor Status</label><select className={inputClass()} value={job.capacitorStatus} onChange={(e) => updateJob("capacitorStatus", e.target.value)}><option>Good</option><option>Low</option><option>Bad</option></select></div>
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div><label className="mb-2 block text-sm font-medium">UV Bulb Condition</label><select className={inputClass()} value={job.uvBulb} onChange={(e) => updateJob("uvBulb", e.target.value)}><option>Good</option><option>Weak</option><option>Out</option></select></div>
                      <div><label className="mb-2 block text-sm font-medium">Airflow Notes</label><textarea className={inputClass("min-h-[100px]")} value={job.airflowNotes} onChange={(e) => updateJob("airflowNotes", e.target.value)} /></div>
                    </div>
                  </div>
                )}

                {activeTab === "estimate" && (
                  <div className="mt-6 space-y-4">
                    <div className={cardClass()}>
                      <div className="p-6">
                        <h3 className="text-xl font-bold">Maintenance Actions Completed</h3>
                        <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                          {[
                            ["filter", "Filter checked / replaced"],
                            ["evap", "Evaporator coil inspected / cleaned"],
                            ["cond", "Condenser coil inspected / cleaned"],
                            ["drain", "Drain line flushed"],
                            ["electrical", "Electrical connections tightened"],
                            ["tested", "System cycled and tested"]
                          ].map(([key, label]) => (
                            <label key={key} className="flex items-center gap-3 rounded-2xl border p-4">
                              <input
                                type="checkbox"
                                checked={(maintenanceActions as any)[key]}
                                onChange={(e) => setMaintenanceActions((prev: any) => ({ ...prev, [key]: e.target.checked }))}
                              />
                              <span className="text-sm font-medium">{label}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className={cardClass()}>
                      <div className="p-6">
                        <h3 className="flex items-center gap-2 text-xl font-bold"><Wrench className="h-5 w-5" /> Recommended Repairs</h3>
                        <div className="mt-4 space-y-4">
                          {repairs.map((row, index) => (
                            <div key={index} className="grid gap-3 rounded-2xl border p-4 md:grid-cols-[1fr_140px_120px]">
                              <input
                                className={inputClass()}
                                value={row.item}
                                onChange={(e) => setRepairs((prev) => prev.map((r, i) => i === index ? { ...r, item: e.target.value } : r))}
                                placeholder="Repair item"
                              />
                              <input
                                type="number"
                                className={inputClass()}
                                value={row.price}
                                onChange={(e) => setRepairs((prev) => prev.map((r, i) => i === index ? { ...r, price: Number(e.target.value) } : r))}
                                placeholder="Price"
                              />
                              <button
                                className={buttonClass("border border-slate-300 bg-white")}
                                onClick={() => setRepairs((prev) => prev.filter((_, i) => i !== index))}
                              >
                                Remove
                              </button>
                            </div>
                          ))}
                          <div className="flex flex-wrap gap-3">
                            <button className={buttonClass("bg-sky-600 text-white")} onClick={() => setRepairs((prev) => [...prev, { item: "", price: 0 }])}>
                              Add Repair
                            </button>
                            <div className="rounded-2xl bg-slate-50 px-4 py-3 text-sm font-semibold">Total Estimate: ${totals.estimate}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "closeout" && (
                  <div className="mt-6 grid gap-4 lg:grid-cols-2">
                    <div className={cardClass()}>
                      <div className="p-6">
                        <h3 className="text-xl font-bold">System Result & Notes</h3>
                        <div className="mt-4 space-y-4">
                          <div><label className="mb-2 block text-sm font-medium">Overall Result</label><select className={inputClass()} value={job.systemResult} onChange={(e) => updateJob("systemResult", e.target.value)}><option>System Operating Properly</option><option>Needs Attention</option><option>Fail</option></select></div>
                          <div><label className="mb-2 block text-sm font-medium">Technician Notes</label><textarea className={inputClass("min-h-[180px]")} value={job.notes} onChange={(e) => updateJob("notes", e.target.value)} /></div>
                          <div className="grid grid-cols-2 gap-4">
                            <div><label className="mb-2 block text-sm font-medium">Technician Signature</label><input className={inputClass()} placeholder="Sign here" /></div>
                            <div><label className="mb-2 block text-sm font-medium">Customer Signature</label><input className={inputClass()} placeholder="Sign here" /></div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className={cardClass("bg-slate-50")}>
                      <div className="p-6">
                        <h3 className="flex items-center gap-2 text-xl font-bold"><QrCode className="h-5 w-5" /> Review & Next Actions</h3>
                        <div className="mt-4 rounded-3xl border-2 border-dashed border-sky-200 bg-white p-8 text-center">
                          <Image src="/prime-qr.png" alt="Prime AC QR code" width={140} height={140} className="mx-auto rounded-2xl" />
                          <div className="mt-3 text-lg font-semibold">Prime AC QR Review Capture</div>
                          <p className="mt-2 text-sm text-slate-600">Show the customer this QR code to collect a Google review before leaving the job.</p>
                        </div>
                        <div className="mt-4 grid gap-3 sm:grid-cols-2">
                          <button className={buttonClass("bg-sky-600 text-white")}>Generate Service Report</button>
                          <button className={buttonClass("border border-slate-300 bg-white")}>Generate Invoice</button>
                          <button className={buttonClass("border border-slate-300 bg-white")}>Email Customer</button>
                          <button className={buttonClass("border border-slate-300 bg-white")}>Save Customer History</button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </section>
          </div>
        </div>
      </div>
    </main>
  );
}
